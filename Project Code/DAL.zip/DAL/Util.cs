﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    internal class Util
    {
        public const string connectionString = "Server=mssqlstud.fhict.local;Database=dbi504738_sb08media;User Id=dbi504738_sb08media;Password=seNthOusHInv;";
    }
}
